﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Valinta20_Paananen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_StoP_Click(object sender, EventArgs e)
        {
            double luku1 = double.Parse(txt_luku1.Text);
            double luku2 = double.Parse(txt_luku2.Text);
            double luku3 = double.Parse(txt_luku3.Text);
            double[] luvut;
            luvut = new double[] { luku1, luku2, luku3 };
            Array.Sort(luvut);
            Array.Reverse(luvut);

            for (int i = 0; i < luvut.Length; i++)
            {
                txt_vastaus.Text = luvut[0].ToString() + " " + luvut[1].ToString() + " " + luvut[2].ToString();
            }
        }

        private void btn_PtoS_Click(object sender, EventArgs e)
        {
            double luku1 = double.Parse(txt_luku1.Text);
            double luku2 = double.Parse(txt_luku2.Text);
            double luku3 = double.Parse(txt_luku3.Text);
            double[] luvut;
            luvut = new double[] { luku1, luku2, luku3 };
            Array.Sort(luvut);
            //Array.Reverse(luvut);

            for (int i = 0; i < luvut.Length; i++)
            {
                txt_vastaus.Text = luvut[0].ToString() + " " + luvut[1].ToString() + " " + luvut[2].ToString();
            }
        }
    }
}
