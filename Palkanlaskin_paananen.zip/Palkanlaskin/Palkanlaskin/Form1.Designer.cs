﻿namespace Palkanlaskin
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_laske = new System.Windows.Forms.Button();
            this.lblEuro = new System.Windows.Forms.Label();
            this.lblNormi = new System.Windows.Forms.Label();
            this.lbl50 = new System.Windows.Forms.Label();
            this.lbl100 = new System.Windows.Forms.Label();
            this.txt_Euro = new System.Windows.Forms.TextBox();
            this.txt_Normi = new System.Windows.Forms.TextBox();
            this.txt_yks = new System.Windows.Forms.TextBox();
            this.txt_kaks = new System.Windows.Forms.TextBox();
            this.txt_Yhteensa = new System.Windows.Forms.TextBox();
            this.lblYhteensa = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_laske
            // 
            this.btn_laske.Location = new System.Drawing.Point(153, 408);
            this.btn_laske.Name = "btn_laske";
            this.btn_laske.Size = new System.Drawing.Size(180, 30);
            this.btn_laske.TabIndex = 0;
            this.btn_laske.Text = "Laske";
            this.btn_laske.UseVisualStyleBackColor = true;
            this.btn_laske.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblEuro
            // 
            this.lblEuro.AutoSize = true;
            this.lblEuro.Location = new System.Drawing.Point(51, 53);
            this.lblEuro.Name = "lblEuro";
            this.lblEuro.Size = new System.Drawing.Size(122, 20);
            this.lblEuro.TabIndex = 1;
            this.lblEuro.Text = "Palkka euroina?";
            // 
            // lblNormi
            // 
            this.lblNormi.AutoSize = true;
            this.lblNormi.Location = new System.Drawing.Point(51, 154);
            this.lblNormi.Name = "lblNormi";
            this.lblNormi.Size = new System.Drawing.Size(115, 20);
            this.lblNormi.TabIndex = 2;
            this.lblNormi.Text = "Normaali tunnit";
            // 
            // lbl50
            // 
            this.lbl50.AutoSize = true;
            this.lbl50.Location = new System.Drawing.Point(60, 231);
            this.lbl50.Name = "lbl50";
            this.lbl50.Size = new System.Drawing.Size(94, 20);
            this.lbl50.TabIndex = 3;
            this.lbl50.Text = "+50% tunnit";
            // 
            // lbl100
            // 
            this.lbl100.AutoSize = true;
            this.lbl100.Location = new System.Drawing.Point(51, 332);
            this.lbl100.Name = "lbl100";
            this.lbl100.Size = new System.Drawing.Size(103, 20);
            this.lbl100.TabIndex = 4;
            this.lbl100.Text = "+100% tunnit";
            // 
            // txt_Euro
            // 
            this.txt_Euro.Location = new System.Drawing.Point(233, 53);
            this.txt_Euro.Name = "txt_Euro";
            this.txt_Euro.Size = new System.Drawing.Size(100, 26);
            this.txt_Euro.TabIndex = 5;
            // 
            // txt_Normi
            // 
            this.txt_Normi.Location = new System.Drawing.Point(233, 148);
            this.txt_Normi.Name = "txt_Normi";
            this.txt_Normi.Size = new System.Drawing.Size(100, 26);
            this.txt_Normi.TabIndex = 6;
            // 
            // txt_yks
            // 
            this.txt_yks.Location = new System.Drawing.Point(233, 231);
            this.txt_yks.Name = "txt_yks";
            this.txt_yks.Size = new System.Drawing.Size(100, 26);
            this.txt_yks.TabIndex = 7;
            // 
            // txt_kaks
            // 
            this.txt_kaks.Location = new System.Drawing.Point(233, 332);
            this.txt_kaks.Name = "txt_kaks";
            this.txt_kaks.Size = new System.Drawing.Size(100, 26);
            this.txt_kaks.TabIndex = 8;
            // 
            // txt_Yhteensa
            // 
            this.txt_Yhteensa.Location = new System.Drawing.Point(641, 53);
            this.txt_Yhteensa.Name = "txt_Yhteensa";
            this.txt_Yhteensa.Size = new System.Drawing.Size(100, 26);
            this.txt_Yhteensa.TabIndex = 9;
            // 
            // lblYhteensa
            // 
            this.lblYhteensa.AutoSize = true;
            this.lblYhteensa.Location = new System.Drawing.Point(446, 53);
            this.lblYhteensa.Name = "lblYhteensa";
            this.lblYhteensa.Size = new System.Drawing.Size(125, 20);
            this.lblYhteensa.TabIndex = 10;
            this.lblYhteensa.Text = "Palkka yhteensä";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblYhteensa);
            this.Controls.Add(this.txt_Yhteensa);
            this.Controls.Add(this.txt_kaks);
            this.Controls.Add(this.txt_yks);
            this.Controls.Add(this.txt_Normi);
            this.Controls.Add(this.txt_Euro);
            this.Controls.Add(this.lbl100);
            this.Controls.Add(this.lbl50);
            this.Controls.Add(this.lblNormi);
            this.Controls.Add(this.lblEuro);
            this.Controls.Add(this.btn_laske);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_laske;
        private System.Windows.Forms.Label lblEuro;
        private System.Windows.Forms.Label lblNormi;
        private System.Windows.Forms.Label lbl50;
        private System.Windows.Forms.Label lbl100;
        private System.Windows.Forms.TextBox txt_Euro;
        private System.Windows.Forms.TextBox txt_Normi;
        private System.Windows.Forms.TextBox txt_yks;
        private System.Windows.Forms.TextBox txt_kaks;
        private System.Windows.Forms.TextBox txt_Yhteensa;
        private System.Windows.Forms.Label lblYhteensa;
    }
}

