﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Palkanlaskin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double Euro, Normi, yks, kaks, Yhteensa;
            Euro = double.Parse(txt_Euro.Text);
            Normi = double.Parse(txt_Normi.Text);
            yks = double.Parse(txt_yks.Text);
            kaks = double.Parse(txt_kaks.Text);
            Normi = (Euro * Normi);
            yks = ((Euro * 1.5) * yks);
            kaks = ((Euro * 2) * kaks);
            Yhteensa = (Normi + yks + kaks);
            Yhteensa = Math.Round(Yhteensa, 2);
            txt_Yhteensa.Text = Yhteensa.ToString();

           
        }
    }
}
