﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_KOE3_Paananen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        

        private void btn_ok_Click(object sender, EventArgs e)
        {
            try
            {
                //Kaikki variablet tässä, yritin tehdä aliohjelmoinnilla mutta se ei toiminut jostain syystä joten tein kaiken Ok buttonin alle.
                double kassa, italiah, margheritatulos;
                double perfettah, italiakpl, mozzarellatulos;
                double perfettakpl, italiatulos, tropicanatulos;
                double perfettatulos, margheritah, porotulos;
                double americanah, mozzarellah;
                double americanakpl, margheritakpl;
                double americanatulos, mozarellakpl;
                double operah, tropicanah;
                double operakpl, tropicanakpl;
                double operatulos, poroh, porokpl;
                double mexicanakpl, mexicanah, mexicanatulos;
                double zorbaskpl, zorbash, zorbastulos;
                double tuplakpl, tuplah, tuplatulos;
                double pollokpl, polloh, pollotulos, limpparikpl, limpparih, limpparitulos;

                //Laskut kaikille pitsoille ja checkboxit lisätäytteille.
                perfettah = 13.90;
                if (cbx_1.Checked) perfettah = perfettah + 2;
                if (cbx_2.Checked) perfettah = perfettah + 1;
                if (cbx_3.Checked) perfettah = perfettah + 1.5;
                perfettakpl = double.Parse(txt_perfettakpl.Text);
                americanah = 11.90;
                if (cbx_4.Checked) americanah = americanah + 2;
                if (cbx_5.Checked) americanah = americanah + 1;
                if (cbx_6.Checked) americanah = americanah + 1.5;
                americanakpl = double.Parse(txt_americanakpl.Text);
                operah = 10.90;
                if (cbx_7.Checked) operah = operah + 2;
                if (cbx_8.Checked) operah = operah + 1;
                if (cbx_9.Checked) operah = operah + 1.5;
                operakpl = double.Parse(txt_operakpl.Text);
                italiah = 9.90;
                if (cbx_10.Checked) perfettah = perfettah + 2;
                if (cbx_11.Checked) perfettah = perfettah + 1;
                if (cbx_12.Checked) perfettah = perfettah + 1.5;
                italiakpl = double.Parse(txt_italiakpl.Text);
                margheritah = 11.90;
                if (cbx_13.Checked) margheritah = margheritah + 2;
                if (cbx_14.Checked) margheritah = margheritah + 1;
                if (cbx_15.Checked) margheritah = margheritah + 1.5;
                margheritakpl = double.Parse(txt_margheritakpl.Text);
                mozzarellah = 14.90;
                if (cbx_16.Checked) mozzarellah = mozzarellah + 2;
                if (cbx_17.Checked) mozzarellah = mozzarellah + 1;
                if (cbx_18.Checked) mozzarellah = mozzarellah + 1.5;
                mozarellakpl = double.Parse(txt_mozarellakpl.Text);
                tropicanah = 10.90;
                if (cbx_19.Checked) tropicanah = tropicanah + 2;
                if (cbx_20.Checked) tropicanah = tropicanah + 1;
                if (cbx_21.Checked) tropicanah = tropicanah + 1.5;
                tropicanakpl = double.Parse(txt_tropicanakpl.Text);
                poroh = 9.90;
                if (cbx_22.Checked) poroh = poroh + 2;
                if (cbx_23.Checked) poroh = poroh + 1;
                if (cbx_24.Checked) poroh = poroh + 1.5;
                porokpl = double.Parse(txt_porokpl.Text);
                mexicanah = 11.90;
                if (cbx_25.Checked) mexicanah = mexicanah + 2;
                if (cbx_26.Checked) mexicanah = mexicanah + 1;
                if (cbx_27.Checked) mexicanah = mexicanah + 1.5;
                mexicanakpl = double.Parse(txt_mexicanakpl.Text);
                zorbash = 13.90;
                if (cbx_28.Checked) zorbash = zorbash + 2;
                if (cbx_29.Checked) zorbash = zorbash + 1;
                if (cbx_30.Checked) zorbash = zorbash + 1.5;
                zorbaskpl = double.Parse(txt_zorbaskpl.Text);
                tuplah = 12.90;
                if (cbx_31.Checked) tuplah = tuplah + 2;
                if (cbx_32.Checked) tuplah = tuplah + 1;
                if (cbx_33.Checked) tuplah = tuplah + 1.5;
                tuplakpl = double.Parse(txt_tuplakpl.Text);
                polloh = 13.90;
                if (cbx_34.Checked) polloh = polloh + 2;
                if (cbx_35.Checked) polloh = polloh + 1;
                if (cbx_36.Checked) polloh = polloh + 1.5;
                pollokpl = double.Parse(txt_pollokpl.Text);
                limpparih = 2.99;
                limpparikpl = double.Parse(textBox1.Text);


                //Laskut pitsan loppuhinnalle
                americanatulos = americanah * americanakpl;
                perfettatulos = perfettah * perfettakpl;
                operatulos = operah * operakpl;
                italiatulos = italiah * italiakpl;
                margheritatulos = margheritah * margheritakpl;
                mozzarellatulos = mozzarellah * mozarellakpl;
                tropicanatulos = tropicanah * tropicanakpl;
                porotulos = poroh * porokpl;
                mexicanatulos = mexicanah * mexicanakpl;
                zorbastulos = zorbash * zorbaskpl;
                tuplatulos = tuplah * tuplakpl;
                pollotulos = polloh * pollokpl;
                limpparitulos = limpparih * limpparikpl;

                //lasku laittamaan lopputulos kassaan.
                kassa = americanatulos + perfettatulos + operatulos + italiatulos + margheritatulos + mozzarellatulos + tropicanatulos + porotulos + mexicanatulos + zorbastulos + tuplatulos + pollotulos + limpparitulos;
                txt_kassa.Text = kassa.ToString();
            }

            catch (Exception) { MessageBox.Show("Laita numero tuotteen lukumäärään"); }
            
                





        }
    }
}
