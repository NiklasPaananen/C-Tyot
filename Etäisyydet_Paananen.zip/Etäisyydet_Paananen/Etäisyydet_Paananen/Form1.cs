﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Etäisyydet_Paananen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public double Muunnin(double m, string unit)
        {
            double tulos = 0.0;

            if (unit == "cm")
                tulos = m * 100;
            else if (unit == "dm")
                tulos = m * 10;
            else if (unit == "km")
                tulos = m / 1000;
            else if (unit == "inch")
                tulos = m * 39.37;
            else if (unit == "ft")
                tulos = m * 3.28;
            else if (unit == "yd")
                tulos = m * 1.09;

            return tulos;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double m = double.Parse(txt_metri.Text);
            double tulos = Muunnin(m, "m");

            txt_cm.Text = Muunnin(m, "cm").ToString();
            txt_dm.Text = Muunnin(m, "dm").ToString();
            txt_km.Text = Muunnin(m, "km").ToString();
            txt_in.Text = Muunnin(m, "inch").ToString();
            txt_ft.Text = Muunnin(m, "ft").ToString();
            txt_yd.Text = Muunnin(m, "yd").ToString();
        }
    }
}